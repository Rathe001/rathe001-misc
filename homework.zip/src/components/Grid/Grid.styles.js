import iconDownload from '../../images/iconDownload.png';

const fontStack = '"Open Sans", Helvetica, Arial, sans-serif';

export default {
  availableStatus: {
    '&::before': {
      background: '#82CE36',
      borderRadius: 8,
      content: '""',
      height: 16,
      left: -24,
      position: 'absolute',
      top: 0,
      width: 16,
    },
  },
  btnDownload: {
    background: `url(${iconDownload}) 0 50% no-repeat`,
    backgroundSize: 'contain',
    border: 'none',
    cursor: 'pointer',
    fontFamily: fontStack,
    fontSize: 16,
    lineHeight: '16px',
    margin: '0 0 0 50px',
    padding: '0 0 0 25px',
  },
  grid: {
    boxShadow: '0 0 3px rgba(0, 0, 0, 0.2)',
    fontFamily: fontStack,
    margin: 5,
    maxWidth: 1000,
  },
  gridActions: {
    borderBottom: '1px solid #e6e6e6',
    padding: 10,
  },
  numSelected: {
    marginLeft: 20,
  },
  selected: {
    background: '#efeeef',
  },
  status: {
    position: 'relative',
    textTransform: 'capitalize',
  },
  table: {
    '& td': {
      fontSize: 11,
      fontWeight: 400,
      padding: 10,
      textAlign: 'left',
    },
    '& th': {
      fontSize: 14,
      fontWeight: 300,
      padding: 10,
      textAlign: 'left',
    },
    '& tr': {
      '&:hover': {
        background: '#f5f4f4',
      },
      borderBottom: '1px solid #e6e6e6',
    },
    width: '100%',
  },
};
