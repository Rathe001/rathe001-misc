import { useRef, useEffect } from 'react';
import { createUseStyles } from 'react-jss';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import styles from './Grid.styles';

const useStyles = createUseStyles(styles);

/** NOTE:
 * This component could be consistered an external module.  All state and data is external,
 * soo the business/app logic decoupled from the UI.
 *
 * I opted to used a table since it makes sense for simplicity, but a flexbox would allow
 * more control over responsive design.
 *
 * As is, the component is simple enough to keep in a single file. As complexity grows,
 * it would likely be broken into additional components (ex. Row, Cell, Header, Footer, etc)
 */
function Grid({
  caption,
  columnDefs,
  data,
  numSelected,
  onDownload,
  onSelectAll,
  onSelectRow,
}) {
  /** ref is necessary because a checkbox's indeterminate status must be set programmatically */
  const selectAllRef = useRef(null);
  const classes = useStyles();

  /** Formats contents of a cell based on data type. Not not many types right now. */
  const formatCell = ({ col, index, row }) => {
    switch (col.type) {
      case 'select': {
        const rowNum = index + 1;
        return (
          <>
            <label
              htmlFor={`selectRow${rowNum}`}
              className="sr-only"
            >
              {`Select row ${rowNum}`}
            </label>
            <input
              id={`selectRow${rowNum}`}
              type="checkbox"
              checked={row[col.key]}
              onChange={() => onSelectRow(index)}
            />
          </>
        );
      }
      case 'status': {
        return (
          <span className={classnames(classes.status, {
            [classes.availableStatus]: row.status === 'available',
          })}
          >
            {row[col.key]}
          </span>
        );
      }
      default: {
        return row[col.key];
      }
    }
  };

  /** Updates the state of the "Select all" checkbox */
  useEffect(() => {
    selectAllRef.current.checked = numSelected === data.length && data.length > 0;
    selectAllRef.current.indeterminate = numSelected !== data.length && numSelected !== 0;
  }, [data.length, numSelected]);

  return (
    <div className={classes.grid}>
      <div className={classes.gridActions}>
        <label htmlFor="selectAll" className="sr-only">
          {numSelected === data.length ? 'Unselect All' : 'Select All'}
        </label>
        <input
          id="selectAll"
          ref={selectAllRef}
          type="checkbox"
          onClick={onSelectAll}
        />
        <span className={classes.numSelected}>
          {numSelected === 0 ? 'None Selected' : `Selected ${numSelected}`}
        </span>
        {numSelected > 0 && (
          <button type="button" onClick={onDownload} className={classes.btnDownload}>
            Download Selected
          </button>
        )}
      </div>
      <table className={classes.table}>
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr>
            {columnDefs.map((col) => (
              <th key={col.key}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={row.name} className={row.selected ? classes.selected : undefined}>
              {columnDefs.map((col) => (
                <td key={col.key}>
                  {formatCell({ col, index: i, row })}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

Grid.propTypes = {
  caption: PropTypes.string,
  columnDefs: PropTypes.arrayOf(PropTypes.shape({})),
  data: PropTypes.arrayOf(PropTypes.shape({})),
  numSelected: PropTypes.number,
  onDownload: PropTypes.func,
  onSelectAll: PropTypes.func,
  onSelectRow: PropTypes.func,
};

Grid.defaultProps = {
  caption: undefined,
  columnDefs: undefined,
  data: undefined,
  numSelected: undefined,
  onDownload: () => {},
  onSelectAll: () => {},
  onSelectRow: () => {},
};

export default Grid;
