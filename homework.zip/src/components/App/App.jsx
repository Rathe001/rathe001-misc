import { useState } from 'react';
import DownloadFilesGrid from '../Grid/Grid';
import './App.styles.css';
import columnDefs from '../../mocks/columnDefs.json';
import mockData from '../../mocks/data.json';

/**
 * NOTE:
 * This component is just a simple wrapper for the reusable Grid component.
 * To keep things clean, global CSS reset and sr-only is applied here.
 *
 * Application logic is implemented here, and passed into the Grid component.
 *
 * In a real world scenario, data would be moved to a global data store
 */
function App() {
  const [data, setData] = useState(mockData.map((d) => ({
    ...d,
    selected: false,
  })));

  /** Update a single row selection, without mutations */
  const onSelectRow = (i) => {
    setData((state) => state
      .map((row, index) => ({
        ...row,
        selected: index === i ? !row.selected : row.selected,
      })));
  };

  /** Update a all row selections, without mutations */
  const onSelectAll = () => {
    setData((state) => {
      const hasUnselected = state.find((d) => !d.selected);
      return state.map((row) => ({
        ...row,
        selected: hasUnselected,
      }));
    });
  };

  /** Filters unavailble files and shows the download alert */
  const onDownload = () => {
    const selectedRows = data.filter((d) => d.selected && d.status === 'available');
    const alertString = selectedRows.length > 0
      ? selectedRows.map((d) => `${d.device}: ${d.path}`).join('\n\n')
      : 'Sorry, only files with a status of Available can be downloaded at this time.';

    // eslint-disable-next-line no-alert
    window.alert(alertString);
  };

  return (
    <div className="App">
      <DownloadFilesGrid
        data={data}
        columnDefs={columnDefs}
        caption="Select files to download"
        onSelectRow={onSelectRow}
        onSelectAll={onSelectAll}
        onDownload={onDownload}
        numSelected={data.filter((d) => d.selected).length}
      />
    </div>
  );
}

export default App;
